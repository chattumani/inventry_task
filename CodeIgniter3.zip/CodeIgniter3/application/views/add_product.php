<!DOCTYPE html>
<html>
<head>
    <title>Add Product</title>
</head>
<body>
    <h1>Add Product</h1>
    <form method="post" action="<?= base_url('index.php/ProductController/addProduct') ?>">
        <label for="product_name">Product Name:</label><br>
        <input type="text" id="product_name" name="product_name" required><br><br>
        
        <label for="product_image">Product Image URL:</label><br>
        <input type="text" id="product_image" name="product_image" required><br><br>
        
        <label for="product_category">Product Category:</label><br>
        <select id="product_category" name="product_category" required>
            <option value="Category 1">Category 1</option>
            <option value="Category 2">Category 2</option>
            <!-- Add other category options -->
        </select><br><br>
        
        <label for="stock_count">Stock Count:</label><br>
        <input type="number" id="stock_count" name="stock_count" required><br><br>
        
        <input type="submit" value="Add Product">
    </form>
</body>
</html>
