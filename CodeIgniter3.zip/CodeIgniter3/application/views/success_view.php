<!DOCTYPE html>
<html>
<head>
    <title>Success</title>
</head>
<body>
    <h1>Success</h1>
    <p>Product added successfully!</p>
</body>
</html>
