<?php
// Path to your CodeIgniter's index.php
$codeigniter_path = '/localhost/CodeIgniter3/index.php/ProductController/addProduct';

// Load CodeIgniter
require_once($codeigniter_path . 'index.php');

// Initialize CI instance
$CI = &get_instance();
$CI->load->model('Product_model');
$CI->load->model('Email_model');

// Check low stock products
$lowStockProducts = $CI->Product_model->checkLowStockProducts();

foreach ($lowStockProducts as $product) {
    $CI->Email_model->sendLowInventoryEmail($product['product_id']);
}
