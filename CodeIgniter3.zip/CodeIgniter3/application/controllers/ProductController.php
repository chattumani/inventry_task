<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProductController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Product_model'); // Load the Product_model
        $this->load->helper('url'); // Load URL helper for redirect
		$this->load->library('form_validation');
		$this->load->model('Email_model'); 
    }

    // API endpoint to add a new product
public function addProduct() {
    // Validate form data
    $this->form_validation->set_rules('product_name', 'Product Name', 'required');
    $this->form_validation->set_rules('product_image', 'Product Image', 'required');
    $this->form_validation->set_rules('product_category', 'Product Category', 'required');
    $this->form_validation->set_rules('stock_count', 'Stock Count', 'required|numeric');

    if ($this->form_validation->run() === FALSE) {
        // Validation failed, show error or redirect back to the form
        $this->load->view('add_product'); // Load view for displaying the add product form
    } else {
        // Form data is valid, proceed with inserting into the database
        $data = array(
            'product_name' => $this->input->post('product_name'),
            'product_image' => $this->input->post('product_image'),
            'product_category' => $this->input->post('product_category'),
            'stock_count' => $this->input->post('stock_count')
        );
        $this->Product_model->addProduct($data);

        // Show a success message or redirect to a success page
        $this->load->view('success_view'); // Load view for displaying a success message
    }
}



    // API endpoint to update an existing product
    public function updateProduct($product_id) {
        $data = array(
            'product_name' => $this->input->post('product_name'),
            'product_image' => $this->input->post('product_image'),
            'product_category' => $this->input->post('product_category'),
            'stock_count' => $this->input->post('stock_count')
        );
        $this->Product_model->updateProduct($product_id, $data);
        // You might want to redirect or return a success response
    }

    // API endpoint to delete a product by its ID
    public function deleteProduct($product_id) {
        $this->Product_model->deleteProduct($product_id);
        //Enter the URL directly in your browser's address bar:
       //http://localhost/CodeIgniter3/index.php/ProductController/deleteProduct/1
		
    }

    // API endpoint to get all products
    public function getAllProducts() {
        $products = $this->Product_model->getAllProducts();
        header('Content-Type: application/json');
        echo json_encode($products);
		//Note Enter the URL directly in your browser's address bar: 
		//http://localhost/CodeIgniter3/index.php/ProductController/getAllProducts
    }

    // Example method to check low stock products and trigger email notifications
   public function checkLowStockProducts() {
    $lowStockProducts = $this->Product_model->checkLowStockProducts();
    if (!empty($lowStockProducts)) {
        foreach ($lowStockProducts as $product) {
            $this->load->model('Email_model');
            $this->Email_model->sendLowInventoryEmail($product['id']);
        }
        echo "Low stock products checked and notifications sent if needed.";
    } else {
        echo "No low stock products found.";
    }
	//Note Access the URL corresponding to this method in your browser:
	//http://localhost/CodeIgniter3/index.php/ProductController/checkLowStockProducts
}
	
	public function subscribeForNotifications($product_id, $email) {
    // Check if product exists and its stock count is less than 5
    $product = $this->Product_model->getProductById($product_id);

    if ($product && $product['stock_count'] < 5) {
        // Save the email subscription for this product
        $this->Email_model->saveSubscription($product_id, $email);
        echo "You have subscribed to notifications for this product.";
    } else {
        echo "This product doesn't meet the criteria for subscription.";
    }
}

public function testSubscribeNotifications() {
    $product_id = 123; // Replace with an actual product ID
    $email = 'test@example.com'; // Replace with an actual email
    $result = $this->Email_model->subscribeForNotifications($product_id, $email);
    if ($result) {
        echo 'Subscription successful.';
    } else {
        echo 'Subscription failed.';
    }
}
}
