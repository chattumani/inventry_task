<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EmailController extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Email_model'); // Load the Email_model
        $this->load->helper('url'); // Load URL helper for redirect
        $this->load->library('form_validation'); // Load form validation library
    }

    // API endpoint to register an email for low inventory notifications
   public function registerEmail() {
    $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

    if ($this->form_validation->run() === FALSE) {
        $response = array('error' => validation_errors());
        $this->output->set_content_type('application/json')->set_output(json_encode($response));
    } else {
        $email = $this->input->post('email');
        log_message('debug', 'Received email: ' . $email);

        $result = $this->Email_model->registerEmail($email);

        if ($result) {
            $response = array('message' => 'Email registered successfully!');
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        } else {
            $response = array('error' => 'Failed to register email!');
            $this->output->set_content_type('application/json')->set_output(json_encode($response));
        }
    }
}



    // API endpoint to get all registered emails for low inventory notifications
    public function getAllSubscribedEmails() {
        $emails = $this->Email_model->getAllSubscribedEmails();
        $this->output->set_content_type('application/json')->set_output(json_encode($emails));
    }
	
	public function testGetAllSubscribedEmails() {
    $emails = $this->Email_model->getAllSubscribedEmails();
    if ($emails) {
        echo 'Subscribed emails:';
        print_r($emails);
    } else {
        echo 'No subscribed emails found.';
    }
}
}
