-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 17, 2023 at 05:54 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_management_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `email_subscriptions`
--

CREATE TABLE `email_subscriptions` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_image` varchar(255) NOT NULL,
  `product_category` varchar(100) NOT NULL,
  `stock_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `product_image`, `product_category`, `stock_count`) VALUES
(2, 'Product Name:', 'https://www.google.com/imgres?imgurl=https%3A%2F%2Fcdn-images.zety.com%2Fpages%2Fwhat_are_technical_skills_and_how_to_show_them.jpg&tbnid=sTa4pgBGBicO8M&vet=12ahUKEwiHrbL1nsuCAxUq2zgGHX3iBWAQMygAegQIARBJ..i&imgrefurl=https%3A%2F%2Fzety.com%2Fblog%2Ftechni', 'Category 1', 1),
(3, 'Product Name:', 'https://www.google.com/imgres?imgurl=https%3A%2F%2Fcdn-images.zety.com%2Fpages%2Fwhat_are_technical_skills_and_how_to_show_them.jpg&tbnid=sTa4pgBGBicO8M&vet=12ahUKEwiHrbL1nsuCAxUq2zgGHX3iBWAQMygAegQIARBJ..i&imgrefurl=https%3A%2F%2Fzety.com%2Fblog%2Ftechni', 'Category 2', 4),
(4, 'Product Name:', 'https://www.google.com/imgres?imgurl=https%3A%2F%2Fcdn-images.zety.com%2Fpages%2Fwhat_are_technical_skills_and_how_to_show_them.jpg&tbnid=sTa4pgBGBicO8M&vet=12ahUKEwiHrbL1nsuCAxUq2zgGHX3iBWAQMygAegQIARBJ..i&imgrefurl=https%3A%2F%2Fzety.com%2Fblog%2Ftechni', 'Category 1', 7),
(5, 'Product Name:', 'https://www.google.com/imgres?imgurl=https%3A%2F%2Fcdn-images.zety.com%2Fpages%2Fwhat_are_technical_skills_and_how_to_show_them.jpg&tbnid=sTa4pgBGBicO8M&vet=12ahUKEwiHrbL1nsuCAxUq2zgGHX3iBWAQMygAegQIARBJ..i&imgrefurl=https%3A%2F%2Fzety.com%2Fblog%2Ftechni', 'Category 1', 7);

-- --------------------------------------------------------

--
-- Table structure for table `registered_emails`
--

CREATE TABLE `registered_emails` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions_table`
--

CREATE TABLE `subscriptions_table` (
  `id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscriptions_table`
--

INSERT INTO `subscriptions_table` (`id`, `product_id`, `email`, `created_at`) VALUES
(1, 2, 'manish.chturvedi@gmail.com', '2023-11-17 15:56:01'),
(2, 2, 'manish.chturvedi@gmail.com', '2023-11-17 16:05:54'),
(3, 2, 'manish.chturvedi@gmail.com', '2023-11-17 16:05:54'),
(4, 4, 'manish.chturvedi@gmail.com', '2023-11-17 16:06:06'),
(5, 4, 'manish.chturvedi@gmail.com', '2023-11-17 16:06:08'),
(6, 4, 'manish.chturvedi@gmail.com', '2023-11-17 16:06:16'),
(7, 3, 'manish.chturvedi@gmail.com', '2023-11-17 16:08:05'),
(8, 3, 'manish.chturvedi@gmail.com', '2023-11-17 16:08:06'),
(9, 3, 'manish.chturvedi@gmail.com', '2023-11-17 16:08:12');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `email_subscriptions`
--
ALTER TABLE `email_subscriptions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registered_emails`
--
ALTER TABLE `registered_emails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscriptions_table`
--
ALTER TABLE `subscriptions_table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `email_subscriptions`
--
ALTER TABLE `email_subscriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `registered_emails`
--
ALTER TABLE `registered_emails`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscriptions_table`
--
ALTER TABLE `subscriptions_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
