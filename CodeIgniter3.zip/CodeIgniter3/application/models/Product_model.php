<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database(); // Load database connection
    }

    // Add a new product to the database
    public function addProduct($data) {
        $this->db->insert('products', $data);
        return $this->db->insert_id(); // Return the ID of the inserted product
    }

    // Get details of a product by its ID
    public function getProductById($product_id) {
        $this->db->where('id', $product_id);
        $query = $this->db->get('products');
        return $query->row_array();
    }

    // Update product details
    public function updateProduct($product_id, $data) {
        $this->db->where('id', $product_id);
        $this->db->update('products', $data);
        return $this->db->affected_rows();
    }

    // Delete a product by its ID
    public function deleteProduct($product_id) {
        $this->db->where('id', $product_id);
        $this->db->delete('products');
        return $this->db->affected_rows();
    }

    // Get all products from the database
    public function getAllProducts() {
        $query = $this->db->get('products');
        return $query->result_array();
    }

    // Example method to check inventory for low stock products
    public function checkLowStockProducts() {
        $this->db->where('stock_count <', 5);
        $query = $this->db->get('products');
        return $query->result_array();
    }
}
