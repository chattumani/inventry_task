<form method="post" action="<?= base_url('index.php/EmailController/registerEmail') ?>">
    <input type="text" name="email" placeholder="Enter your email">
    <button type="submit">Register Email</button>
</form>