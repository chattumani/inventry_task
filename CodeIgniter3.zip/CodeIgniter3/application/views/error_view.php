<!DOCTYPE html>
<html>
<head>
    <title>Error</title>
</head>
<body>
    <h1>Error</h1>
    <p>An error occurred. Please check your input and try again.</p>
</body>
</html>
