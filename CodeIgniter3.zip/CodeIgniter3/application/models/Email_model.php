<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Email_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database(); // Load database connection
    }

    // Register an email for low inventory notifications
    public function registerEmail($email) {
        $data = array(
            'email' => $email
            // Other necessary fields if needed
        );
        $this->db->insert('email_subscriptions', $data);
        return $this->db->insert_id(); // Return the ID of the inserted subscription
    }

    // Get all registered emails for low inventory notifications
    public function getAllSubscribedEmails() {
        $query = $this->db->get('email_subscriptions');
        return $query->result_array();
    }

    // Example method to send low inventory email notifications
   public function sendLowInventoryEmail($product_id) {
    // Retrieve product details from the database
    $product = $this->Product_model->getProductById($product_id);

    if ($product && $product['stock_count'] < 5) {
        $subject = "{$product['id']} inventory is low. Please update it.";
        $message = "The inventory for {$product['product_name']} is low. Current stock count: {$product['stock_count']}.";

        $this->load->library('email');

        $this->email->from('manish.chturvedi@gmail.com', 'Manish Chaturvedi');
        $this->email->to('admin@example.com'); // Replace with admin email

        $this->email->subject($subject);
        $this->email->message($message);

        if ($this->email->send()) {
            echo 'Email sent successfully.';
        } else {
            echo 'Email sending failed.';
            echo $this->email->print_debugger(); // Print any email sending errors
        }
    }
}
	public function subscribeForNotifications($product_id, $email) {
    // Save the email subscription for the product
    $data = array(
        'product_id' => $product_id,
        'email' => $email
    );
    $this->db->insert('subscriptions_table', $data);
}
}
