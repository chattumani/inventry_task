<!DOCTYPE html>
<html>
<head>
    <title>Register Email</title>
</head>
<body>
    <h1>Register Email for Notifications</h1>
    <form method="post" action="<?= base_url('index.php/EmailController/registerEmail') ?>">
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" required><br><br>
        
        <input type="submit" value="Register Email">
    </form>
</body>
</html>
